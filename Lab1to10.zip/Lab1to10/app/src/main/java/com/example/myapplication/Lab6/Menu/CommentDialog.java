package com.example.myapplication.Lab6.Menu;

import androidx.fragment.app.DialogFragment;

public class CommentDialog {
    public static DialogFragment newInstance() {
        return null;
    }
}
