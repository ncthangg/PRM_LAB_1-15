package com.example.vnpay;

public class Config {
    public static final String VNPAY_URL = "https://sandbox.vnpayment.vn/paymentv2/vpcpay.html";
    public static final String VNPAY_TMN_CODE = "HHIW000B";
    public static final String VNPAY_HASH_SECRET = "CNDEEZU58XDP1JG46QJISMOH6MZKHS7U";
}
